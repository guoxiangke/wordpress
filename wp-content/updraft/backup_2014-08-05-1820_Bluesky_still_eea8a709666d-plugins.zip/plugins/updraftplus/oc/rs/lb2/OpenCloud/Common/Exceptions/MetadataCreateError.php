<?php

namespace OpenCloud\Common\Exceptions;

class MetadataCreateError extends \Exception {}
