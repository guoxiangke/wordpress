<?php

namespace OpenCloud\Common\Exceptions;

class AsyncError extends \Exception {}
