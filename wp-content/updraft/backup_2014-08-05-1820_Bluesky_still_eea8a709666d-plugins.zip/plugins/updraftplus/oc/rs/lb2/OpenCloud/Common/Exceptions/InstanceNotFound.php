<?php

namespace OpenCloud\Common\Exceptions;

class InstanceNotFound extends \Exception {}
